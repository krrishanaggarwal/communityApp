// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:community/pages/home.dart';
import 'package:community/pages/theme.dart';

import 'package:flutter/material.dart';
import 'package:flutter_downloader/flutter_downloader.dart';
import 'package:provider/provider.dart';
// import 'package:fluttershare/pages/home.dart';

void main() async {
  // Firestore.instance.settings(timestampsInSnapshotsEnabled: true).then((_) {
  //   print("timestamp enables\n");
  // }, onError: (_) {
  //   print("error\n");
  // });
  WidgetsFlutterBinding.ensureInitialized();
  await FlutterDownloader.initialize(
      debug: true // optional: set false to disable printing logs to console
      );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => ThemeNotifier(),
      child: Consumer<ThemeNotifier>(
        builder: (context, ThemeNotifier notifier, child) {
          return MaterialApp(
            title: 'community',
            debugShowCheckedModeBanner: false,
            theme: notifier.darktheme ? dark : light,
            home: Home(),
          );
        },
      ),
    );
  }
}

// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:community/pages/home.dart';
// import 'package:device_preview/device_preview.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_downloader/flutter_downloader.dart';
// // import 'package:fluttershare/pages/home.dart';

// void main() async {
//   // Firestore.instance.settings(timestampsInSnapshotsEnabled: true).then((_) {
//   //   print("timestamp enables\n");
//   // }, onError: (_) {
//   //   print("error\n");
//   // });
//   WidgetsFlutterBinding.ensureInitialized();
//   await FlutterDownloader.initialize(
//       debug: true // optional: set false to disable printing logs to console
//       );
//   runApp(DevicePreview(builder: (context) => MyApp()));
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'community',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         fontFamily: "Ubuntu",
//         primarySwatch: Colors.pink,
//         accentColor: Colors.indigo,
//         // fontFamily: "Ubuntu"
//         brightness: Brightness.dark,
//       ),
//       home: Home(),
//     );
//   }
// }

// void main() async {
//   // Firestore.instance.settings(timestampsInSnapshotsEnabled: true).then((_) {
//   //   print("timestamp enables\n");
//   // }, onError: (_) {
//   //   print("error\n");
//   // });
//   WidgetsFlutterBinding.ensureInitialized();
//   await FlutterDownloader.initialize(
//       debug: true // optional: set false to disable printing logs to console
//       );
//   runApp(MyApp());
// }

// class MyApp extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'community',
//       debugShowCheckedModeBanner: false,
//       theme: ThemeData(
//         fontFamily: "Ubuntu",
//         primarySwatch: Colors.pink,
//         accentColor: Colors.black,
//         // fontFamily: "Ubuntu"
//         // brightness: Brightness.dark,
//       ),
//       home: Home(),
//     );
//   }
// }
