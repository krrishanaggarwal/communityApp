import 'package:cloud_firestore/cloud_firestore.dart';

class User {
  final String id;
  final String webLink;
  final String username;
  final String email;
  final String photoUrl;
  final String fieldOfInterest;
  final String displayName;
  final bool isOrganizer;

  User(
      {this.webLink,
      this.fieldOfInterest,
      this.displayName,
      this.email,
      this.id,
      this.photoUrl,
      this.username,
      this.isOrganizer});

  factory User.fromDocument(DocumentSnapshot doc) {
    return User(
        id: doc['id'],
        email: doc['email'],
        username: doc['username'],
        photoUrl: doc['photoUrl'],
        displayName: doc['displayName'],
        fieldOfInterest: doc['fieldOfInterest'],
        webLink: doc['webLink'],
        isOrganizer: doc['isOrganizer']);
  }
}
