class Model {
  String username;
  String fieldOfInterest;
  String url;
  Model({this.username, this.fieldOfInterest, this.url});
}
