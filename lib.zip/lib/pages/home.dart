import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:community/models/model.dart';
import 'package:community/pages/logo.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import 'package:google_sign_in/google_sign_in.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

import '../models/user.dart';
import 'activity_feed.dart';
import 'createAccount2.dart';
// import 'create_account.dart';
import 'profile.dart';
import 'search_post.dart';
import 'timeline.dart';
import 'uploadbycategory.dart';

final googleSignIn = GoogleSignIn();
final timestamp = DateTime.now();
final userRef = Firestore.instance.collection('users');
final postRef = Firestore.instance.collection('posts');
final postByCategoryRef = Firestore.instance.collection('postsByCategory');
final commentRef = Firestore.instance.collection('comments');
final activityFeedRef = Firestore.instance.collection('feed');
final organizerEntry = Firestore.instance.collection('OrganizersEntries');

final storageRef = FirebaseStorage.instance.ref();
User currentUser;

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool isAuth = false;
  PageController pageController;
  int pageIndex = 0;
  @override
  void initState() {
    super.initState();
    pageController = PageController();

    //Detects when userSignIn
    googleSignIn.onCurrentUserChanged.listen((account) {
      handleSignIn(account);
    }, onError: (error) {
      print("Error In SignIn$error");
    });
    googleSignIn
        .signInSilently(suppressErrors: false)
        .then((account) => handleSignIn(account))
        .catchError((error) {
      print("Error In SignIn$error");
    });
  }

  handleSignIn(account) async {
    if (account != null) {
      await createUserInFirestore();
      setState(() {
        isAuth = true;
      });
    } else {
      setState(() {
        isAuth = false;
      });
    }
  }

  createUserInFirestore() async {
    final user = googleSignIn.currentUser;
    var doc = await userRef.document(user.id).get();

    if (!doc.exists) {
      Model model = await Navigator.push(
          context, MaterialPageRoute(builder: (context) => CreateAccount2()));
      userRef.document(user.id).setData({
        "id": user.id,
        "username": model.username,
        "photoUrl": user.photoUrl,
        "email": user.email,
        "displayName": user.displayName,
        "webLink": model.url,
        "timestamp": timestamp,
        "fieldOfInterest": model.fieldOfInterest,
        "isOrganizer": false,
      });

      doc = await userRef.document(user.id).get();
    }

    currentUser = User.fromDocument(doc);
  }

  @override
  void dispose() {
    pageController.dispose();
    super.dispose();
  }

  login() {
    googleSignIn.signIn();
  }

  logout() {
    googleSignIn.signOut();
  }

  onPageChanged(int pageIndex) {
    setState(() {
      this.pageIndex = pageIndex;
    });
  }

  onTap(int pageIndex) {
    pageController.animateToPage(pageIndex,
        curve: Curves.easeIn, duration: Duration(milliseconds: 300));
  }

  Widget buildAuthScreen(context) {
    return Scaffold(
      body: PageView(
        children: [
          // RaisedButton(
          //   onPressed: logout,
          //   child: Text("Logout"),
          // ),
          Timeline(),
          ActivityFeed(),
          UploadFile(currentUser: currentUser),
          // Search(),
          SearchPost(),
          Profile(profileId: currentUser?.id),
        ],
        controller: pageController,
        onPageChanged: onPageChanged,
        physics: NeverScrollableScrollPhysics(),
      ),
      bottomNavigationBar: CurvedNavigationBar(
        onTap: onTap,

        animationDuration: Duration(microseconds: 300),
        backgroundColor: Colors.grey[800],

        height: MediaQuery.of(context).size.height * 0.06,
        items: [
          Icon(
            Icons.whatshot_rounded,
            color: Colors.black,
          ),
          Icon(
            Icons.notifications_active,
            color: Colors.black,
          ),
          Icon(
            Icons.photo_camera,
            color: Colors.black,
          ),
          Icon(
            Icons.search,
            color: Colors.black,
          ),
          Icon(
            Icons.account_circle,
            color: Colors.black,
          ),
        ],
        // activeColor: Theme.of(context).accentColor,
      ),
    );
  }

  Widget buildSignInPage() {
    return Scaffold(
      body: Container(
          decoration: BoxDecoration(
              gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Colors.blueGrey[900], Colors.pink[900]],
          )),
          alignment: Alignment.center,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SvgPicture.asset(
                "assets/images/logo.svg",
                height: 200,
              ),
              logo(font: "Signatra", fontsize: 90),
              SizedBox(
                height: 30,
              ),
              InkWell(
                onTap: login,
                splashColor: Theme.of(context).accentColor,
                child: Container(
                  width: 260,
                  height: 60,
                  decoration: BoxDecoration(
                      image: DecorationImage(
                          image: !isAuth
                              ? AssetImage(
                                  'assets/images/google_signin_button.png')
                              : Text(""),
                          fit: BoxFit.fill)),
                ),
              )
            ],
          )),
    );
  }

  @override
  Widget build(BuildContext context) {
    return isAuth ? buildAuthScreen(context) : buildSignInPage();
  }
}
