// import 'dart:async';

// import 'package:community/models/model.dart';
// import 'package:dropdownfield/dropdownfield.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_svg/svg.dart';

// import 'logo.dart';

// class CreateAccount2 extends StatefulWidget {
//   @override
//   _CreateAccount2State createState() => _CreateAccount2State();
// }

// class _CreateAccount2State extends State<CreateAccount2> {
//   final _scaffoldKey = GlobalKey<ScaffoldState>();
//   final _formKey = GlobalKey<FormState>();
//   Model model = Model();

//   buildLogo() {
//     return Column(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: [
//         SvgPicture.asset(
//           "assets/images/logo.svg",
//           height: 150,
//           matchTextDirection: true,
//         ),
//         logo(font: "Signatra", fontsize: 60),
//       ],
//     );
//   }

//   submit() {
//     final form = _formKey.currentState;

//     if (form.validate()) {
//       form.save();
//       SnackBar snackBar = SnackBar(content: Text("Welcome ${model.username}"));
//       _scaffoldKey.currentState.showSnackBar(snackBar);
//       Timer(Duration(seconds: 2), () {
//         if (model.username != null && model.fieldOfInterest != null) {
//           Navigator.pop(context, model);
//         }
//         Navigator.pop(context, model);
//       });
//     }
//   }

//   @override
//   Widget build(BuildContext parentContext) {
//     return SafeArea(
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         key: _scaffoldKey,
//         body: Stack(children: [
//           Container(
//             height: MediaQuery.of(context).size.height * 0.6,
//             width: double.infinity,
//             child: Container(
//               decoration: BoxDecoration(
//                   color: Colors.black,
//                   borderRadius: BorderRadius.only(
//                       bottomLeft: Radius.circular(70),
//                       bottomRight: Radius.circular(70))),
//             ),
//           ),
//           ListView(
//             children: [
//               SizedBox(
//                 height: 50,
//               ),
//               buildLogo(),
//               SizedBox(
//                 height: 60,
//               ),
//               Row(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   ClipRRect(
//                     borderRadius: BorderRadius.all(Radius.circular(20)),
//                     child: Container(
//                       height: MediaQuery.of(context).size.height * 0.7,
//                       width: double.infinity,
//                       decoration: BoxDecoration(
//                         color: Colors.white,
//                       ),
//                       child: ListView(children: [
//                         Column(
//                           mainAxisAlignment: MainAxisAlignment.center,
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                             Padding(
//                               padding: const EdgeInsets.only(top: 12.0),
//                               child: Text(
//                                 "Setup Your Profile",
//                                 style: TextStyle(
//                                   fontSize: 22,
//                                 ),
//                               ),
//                             ),
//                             SizedBox(
//                               height: 30,
//                             ),
//                             Form(
//                                 key: _formKey,
//                                 autovalidateMode:
//                                     AutovalidateMode.onUserInteraction,
//                                 child: Padding(
//                                   padding: const EdgeInsets.all(14.0),
//                                   child: Column(
//                                     children: [
//                                       TextFormField(
//                                         validator: (val) {
//                                           if (val.trim().length < 3 ||
//                                               val.isEmpty) {
//                                             return "UserName too short";
//                                           } else if (val.trim().length > 19) {
//                                             return "UserName too long";
//                                           } else {
//                                             return null;
//                                           }
//                                         },
//                                         onSaved: (val) =>
//                                             model.username = val.toLowerCase(),
//                                         decoration: InputDecoration(
//                                           border: OutlineInputBorder(
//                                               borderRadius:
//                                                   BorderRadius.circular(8)),
//                                           labelText: "UserName",
//                                           labelStyle: TextStyle(fontSize: 16),
//                                           hintText:
//                                               "Must be atleast 4 characters ",
//                                         ),
//                                       ),
//                                       Padding(
//                                         padding:
//                                             const EdgeInsets.only(top: 14.0),
//                                         child: TextFormField(
//                                           onSaved: (val) {
//                                             if (val == null) {
//                                               model.url = "";
//                                             } else {
//                                               model.url = val;
//                                             }
//                                           },
//                                           decoration: InputDecoration(
//                                             border: OutlineInputBorder(
//                                                 borderRadius:
//                                                     BorderRadius.circular(8)),
//                                             labelText: "Your link",
//                                             labelStyle: TextStyle(fontSize: 16),
//                                             hintText:
//                                                 "Must be atleast 4 characters",
//                                           ),
//                                         ),
//                                       ),
//                                       Padding(
//                                         padding:
//                                             const EdgeInsets.only(top: 14.0),
//                                         child: DropDownField(
//                                           // enabled: true,

//                                           required: true,
//                                           itemsVisibleInDropdown: 2,
//                                           items: fields,

//                                           hintText:
//                                               "Choose your Field Of Interest",
//                                           onValueChanged: (value) =>
//                                               model.fieldOfInterest = value,
//                                         ),
//                                       ),
//                                     ],
//                                   ),
//                                 )),
//                             Padding(
//                               padding: const EdgeInsets.only(top: 32.0),
//                               child: GestureDetector(
//                                 onTap: submit,
//                                 child: Container(
//                                   decoration: BoxDecoration(
//                                     color: Theme.of(context).accentColor,
//                                     borderRadius: BorderRadius.circular(18),
//                                   ),
//                                   width: 270,
//                                   height: 45,
//                                   child: Center(
//                                     child: Text(
//                                       "Create",
//                                       style: TextStyle(
//                                           color: Colors.white,
//                                           fontSize: 20,
//                                           fontWeight: FontWeight.bold),
//                                     ),
//                                   ),
//                                 ),
//                               ),
//                             )
//                           ],
//                         ),
//                       ]),
//                     ),
//                   )
//                 ],
//               )
//             ],
//           )
//         ]),
//       ),
//     );
//   }
// }

// List<String> fields = [
//   'Art And Craft',
//   'Photography',
//   'Quotes And Literature',
//   'Design And Illustrations',
//   'Events And Posters',
//   'Other',
// ];
import 'dart:async';

import 'package:community/models/model.dart';
import 'package:dropdownfield/dropdownfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import 'logo.dart';

class CreateAccount2 extends StatefulWidget {
  @override
  _CreateAccount2State createState() => _CreateAccount2State();
}

class _CreateAccount2State extends State<CreateAccount2> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final _formKey = GlobalKey<FormState>();
  Model model = Model();
  buildLogo() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        SvgPicture.asset(
          "assets/images/logo.svg",
          height: 150,
          matchTextDirection: true,
        ),
        logo(font: "Signatra", fontsize: 60),
      ],
    );
  }

  submit() {
    final form = _formKey.currentState;

    if (form.validate()) {
      form.save();
      SnackBar snackBar = SnackBar(content: Text("Welcome ${model.username}"));
      _scaffoldKey.currentState.showSnackBar(snackBar);
      Timer(Duration(seconds: 2), () {
        if (model.username != null && model.fieldOfInterest != null) {
          Navigator.pop(context, model);
        }
        Navigator.pop(context, model);
      });
    }
  }

  @override
  Widget build(BuildContext parentContext) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.white,
        key: _scaffoldKey,
        body: Stack(children: [
          Container(
            height: MediaQuery.of(context).size.height * 0.6,
            width: MediaQuery.of(context).size.width,
            child: Container(
              decoration: BoxDecoration(
                  color: Colors.black,
                  // color: Colors.amber,
                  borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(70),
                      bottomRight: Radius.circular(70))),
            ),
          ),
          ListView(
            children: [
              SizedBox(
                height: 50,
              ),
              buildLogo(),
              SizedBox(
                height: 60,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.all(Radius.circular(20)),
                    child: Container(
                      height: MediaQuery.of(context).size.height * 0.8,
                      width: MediaQuery.of(context).size.width * 0.8,
                      decoration: BoxDecoration(
                        color: Colors.white,
                      ),
                      child: ListView(children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Text(
                                "Setup Your Profile",
                                style: TextStyle(
                                  fontSize: 22,
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            Form(
                                key: _formKey,
                                autovalidateMode:
                                    AutovalidateMode.onUserInteraction,
                                child: Padding(
                                  padding: const EdgeInsets.all(14.0),
                                  child: Column(
                                    children: [
                                      TextFormField(
                                        validator: (val) {
                                          if (val.trim().length < 3 ||
                                              val.isEmpty) {
                                            return "UserName too short";
                                          } else if (val.trim().length > 19) {
                                            return "UserName too long";
                                          } else {
                                            return null;
                                          }
                                        },
                                        onSaved: (val) =>
                                            model.username = val.toLowerCase(),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(8)),
                                          labelText: "UserName",
                                          labelStyle: TextStyle(fontSize: 16),
                                          hintText:
                                              "Must be atleast 4 characters ",
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(top: 14.0),
                                        child: TextFormField(
                                          onSaved: (val) {
                                            if (val == null) {
                                              model.url = "";
                                            } else {
                                              model.url = val;
                                            }
                                          },
                                          decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                                borderRadius:
                                                    BorderRadius.circular(8)),
                                            labelText: "Your link",
                                            labelStyle: TextStyle(fontSize: 16),
                                            hintText:
                                                "Must be atleast 4 characters",
                                          ),
                                        ),
                                      ),
                                      Padding(
                                        padding:
                                            const EdgeInsets.only(top: 14.0),
                                        child: DropDownField(
                                          // enabled: true,

                                          required: true,
                                          itemsVisibleInDropdown: 2,
                                          items: fields,

                                          hintText:
                                              "Choose your Field Of Interest",
                                          onValueChanged: (value) =>
                                              model.fieldOfInterest = value,
                                        ),
                                      ),
                                    ],
                                  ),
                                )),
                            Padding(
                              padding: const EdgeInsets.only(top: 32.0),
                              child: GestureDetector(
                                onTap: submit,
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Theme.of(context).accentColor,
                                    borderRadius: BorderRadius.circular(18),
                                  ),
                                  width: 270,
                                  height: 45,
                                  child: Center(
                                    child: Text(
                                      "Create",
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                            )
                          ],
                        ),
                      ]),
                    ),
                  )
                ],
              )
            ],
          )
        ]),
      ),
    );
//         child: ListView(
//           children: [
//             Padding(
//               padding: const EdgeInsets.all(12.0),
//               child: Text(
//                 "Choose Your UserName",
//                 style: TextStyle(
//                   fontSize: 22,
//                 ),
//               ),
//             ),
//             Form(
//                 key: _formKey,
//                 autovalidateMode: AutovalidateMode.onUserInteraction,
//                 child: Column(
//                   children: [
//                     TextFormField(
//                       validator: (val) {
//                         if (val.trim().length < 3 || val.isEmpty) {
//                           return "UserName too short";
//                         } else if (val.trim().length > 19) {
//                           return "UserName too long";
//                         } else {
//                           return null;
//                         }
//                       },
//                       onSaved: (val) => model.username = val.toLowerCase(),
//                       decoration: InputDecoration(
//                         border: OutlineInputBorder(),
//                         labelText: "UserName",
//                         labelStyle: TextStyle(fontSize: 16),
//                         hintText: "Must be atleast 4 characters",
//                       ),
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.all(10.0),
//                       child: TextFormField(
//                         onSaved: (val) {
//                           if (val == null) {
//                             model.url = "";
//                           } else {
//                             model.url = val;
//                           }
//                         },
//                         decoration: InputDecoration(
//                           border: OutlineInputBorder(),
//                           labelText: "Your link",
//                           labelStyle: TextStyle(fontSize: 16),
//                           hintText: "Must be atleast 4 characters",
//                         ),
//                       ),
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.all(10.0),
//                       child: DropDownField(
//                         // enabled: true,
//                         required: true,
//                         itemsVisibleInDropdown: 4,
//                         items: fields,
//                         hintText: "Choose your Field Of Interest",
//                         onValueChanged: (value) =>
//                             model.fieldOfInterest = value.toLowerCase(),
//                       ),
//                     ),
//                   ],
//                 )),
//             Padding(
//               padding: const EdgeInsets.all(12.0),
//               child: GestureDetector(
//                 onTap: submit,
//                 child: Container(
//                   decoration: BoxDecoration(
//                     color: Theme.of(context).accentColor,
//                     borderRadius: BorderRadius.circular(6),
//                   ),
//                   width: 250,
//                   height: 45,
//                   child: Center(
//                     child: Text(
//                       "Create",
//                       style: TextStyle(
//                           color: Colors.white,
//                           fontSize: 18,
//                           fontWeight: FontWeight.bold),
//                     ),
//                   ),
//                 ),
//               ),
//             )
//           ],
//         ),
//       ),
//     );
//   }
// }
  }
}

List<String> fields = [
  'Art And Craft',
  'Photography',
  'Quotes And Literature',
  'Design And Illustrations',
  'Events And Posters',
  'Other',
];
